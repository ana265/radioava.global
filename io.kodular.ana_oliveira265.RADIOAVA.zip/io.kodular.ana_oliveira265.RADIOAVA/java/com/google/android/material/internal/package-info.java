package com.google.android.material.internal;

import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;

// $FF: synthetic class
@RestrictTo({Scope.LIBRARY_GROUP})
interface package-info {
}
