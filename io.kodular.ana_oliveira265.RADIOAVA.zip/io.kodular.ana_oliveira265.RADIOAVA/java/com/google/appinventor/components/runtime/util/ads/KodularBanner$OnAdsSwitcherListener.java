package com.google.appinventor.components.runtime.util.ads;

public interface KodularBanner$OnAdsSwitcherListener {
   void onAdsClick();

   void onAdsError(String var1);

   void onAdsReady();
}
