package com.google.appinventor.components.runtime;

import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeResponseListener;
import com.google.appinventor.components.runtime.Billing;

final class Billing$6 implements ConsumeResponseListener {
   // $FF: synthetic field
   private Billing hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

   Billing$6(Billing var1) {
      this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = var1;
      super();
   }

   public final void onConsumeResponse(BillingResult var1, String var2) {
   }
}
