package com.google.appinventor.components.runtime.util;

public interface KodularContentProtection$OnValidationResultListener {
   void onResult(boolean var1, boolean var2, String var3);
}
