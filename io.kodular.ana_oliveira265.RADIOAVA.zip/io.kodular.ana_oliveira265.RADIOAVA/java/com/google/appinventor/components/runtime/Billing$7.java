package com.google.appinventor.components.runtime;

import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingResult;
import com.google.appinventor.components.runtime.Billing;

final class Billing$7 implements AcknowledgePurchaseResponseListener {
   // $FF: synthetic field
   private Billing hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

   Billing$7(Billing var1) {
      this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = var1;
      super();
   }

   public final void onAcknowledgePurchaseResponse(BillingResult var1) {
   }
}
