package com.google.appinventor.components.runtime;

import android.content.Intent;

public interface ActivityResultListener {
   void resultReturned(int var1, int var2, Intent var3);
}
