package com.google.appinventor.components.runtime.util;

public interface MakeroidDataProtection$OnConsentListener {
   void result(boolean var1, boolean var2);
}
