package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.runtime.Component;

@SimpleObject
public interface SensorComponent extends Component {
}
