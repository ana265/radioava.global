package com.google.appinventor.components.runtime.util.ads;

public interface KodularInterstitial$OnAdsSwitcherListener {
   void onAdsClick();

   void onAdsClosed();

   void onAdsError(String var1);

   void onAdsReady();
}
