package com.google.appinventor.components.runtime;

public interface OnResumeListener {
   void onResume();
}
