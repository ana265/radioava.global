package com.google.appinventor.components.runtime;

public interface OnDestroyListener {
   void onDestroy();
}
